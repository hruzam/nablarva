#!/bin/sh
# One-shot, for Majkee: fill raw/ of composer-01-parse from the local reposoma checkout, then
# verify against SHA256SUMS (place the bed files first). The bed files never name this source;
# only this helper does. Override paths with REPOSOMA=... BED=...
set -eu
src=${REPOSOMA:-$HOME/reposoma}/.majkee
bed=${BED:-$HOME/unikuklatrix/nablarva/.dev/session/composer-01-parse}

mkdir -p "$bed/raw"
cp -R "$src/projects/unikuklatrix_nablarva-termbrana-X0-prompt-collection/." "$bed/raw/"
for f in 01_SYNC_METHOD 02_PARSER_GATE 04_REGISTRY 05_WAY_OF_THINKING; do
  cp "$src/projects/unikuklatrix_nablarva/$f.md" "$bed/raw/"
done
cp "$src/journal/2026-10-13.md" "$bed/raw/journal.2026-10-13.md"
cp "$src/journal/2026-10-16.md" "$bed/raw/journal.2026-10-16.md"

cd "$bed" && sha256sum -c SHA256SUMS
