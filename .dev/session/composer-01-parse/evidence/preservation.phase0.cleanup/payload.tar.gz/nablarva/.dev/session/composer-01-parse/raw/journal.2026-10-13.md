---
session : `jev-implementation-00-build` (Codex · Cartan head · bounded logger)
---

# 1. JEV

## 1.1. JEV PLAN — pilot first; brief clarity before delegation (bed: `/home/hruzam/ia-sync/.dev/session/jev-implementation-00-build`, head: Cartan)

The proposal lives in [PLAN.md](/home/hruzam/ia-sync/.dev/session/jev-implementation-00-build/PLAN.md). [STATUS.md](/home/hruzam/ia-sync/.dev/session/jev-implementation-00-build/STATUS.md) owns the current next action and wins if this reading aid ever trails it.

### 1.1.1. plan and first-use lean

- [x] Cartan recorded a pilot-first sequence: P0 settles and verifies the contract; P1a proves local records and both consumer faces; P1b proves frozen-send confirmation and failure semantics; P1c is one individually approved live pilot; later P2/P3 trials and promotion need their own scope.
- [x] The preferred first usefulness trial is **brief clarity before delegation**: find missing inputs or an unclear brief before a worker is assigned, then improve the brief or ask one concrete question.
- [x] The dated evidence note records the document verifier PASS and `139/139` tunnel fixture self-tests. Those checks prove planning and fixture behavior, not a Jev implementation or live transport.

### 1.1.2. working seats; transport still inactive

The bed protocol now accepts Cartan as tunnel head and sole [STATUS.md](/home/hruzam/ia-sync/.dev/session/jev-implementation-00-build/STATUS.md) owner. Flight may receive bounded reverse delegations by explicitly assigned files; that narrow assignment overrides earlier ownership restrictions only for those files and does not add an outbound Claude launcher. Flight remains the operator-facing carrier and can independently witness work it did not author.

This accepted working regime is not tunnel activation. No Jev implementation, `~/.jev` store, tunnel vault, current-version live round-trip, credential access, HTTP request or paid call exists at this checkpoint. The operator is reviewing Flight's decision sheet; its boxes were still unchecked at the dated file check, so no answer or gavel is inferred.

The latest read-only head check recorded candidate thread `01a0f5b9-b2ae-7392-af89-f434d5536d88` at `130608/760000` tokens (17.2%), compacted twice, on `gpt-6.1-sol` / high reasoning with `on-request` / user approval. Cartan currently prefers this compressed continuation over a fresh head. It is still only a candidate: no tunnel is enabled, and the interactive client must be explicitly released before any bind/resume work.

The central re-entry pointers are [Cartan head](/home/hruzam/reposoma/_cold-start/card/CS.jev-implementation-00-build.cartan-head.2026-10-12.md) and [Flight carrier](/home/hruzam/reposoma/_cold-start/card/CS.jev-implementation-00-build.flight-carrier.2026-10-12.md); they carry minimal delegated context back to this bed. Their creation does not itself reset, transfer, bind, resume or enable a tunnel. This journal chapter was drafted by one bounded ordinary spawn; it creates no global journaling agent or binding.

### 1.1.3. factual holds

- Implementation waits for actual operator answers, Flight's cycle-01 verification and a bounded implementation POINT.
- Flight must explicitly review the malformed-tail contract and the proposed operator-send acceptance mapping before coding.
- Tunnel enablement and a current-version live round-trip remain operator-owned; fixture success does not satisfy that proof.
- Credentials, spending, deployment, wallet work, watchers, automatic advice, JUD, cascades and learning remain outside the current gate.

### 1.1.4. operator reading aid

These boxes are navigation only; they do not create another next-action authority. [STATUS.md](/home/hruzam/ia-sync/.dev/session/jev-implementation-00-build/STATUS.md) owns the live edge.

- [ ] Majkee finishes reviewing and records his own answers in [the Flight-written decision sheet](/home/hruzam/ia-sync/.dev/session/jev-implementation-00-build/raw/majkee-gavels.2026-10-12.md).
- [ ] Flight verifies cycle 01 against the October 5 design, PLAN and the actual answers, then writes its independent `_bus/01.flight.verdict.md`.
- [ ] Cartan checks that evidence, reconciles STATUS and issues a bounded implementation POINT only after the recorded holds clear.

**Continue here:** open [STATUS.md](/home/hruzam/ia-sync/.dev/session/jev-implementation-00-build/STATUS.md), then follow its `next:` against the actual decision sheet and any Flight verdict.

<!-- cartan-jev-handoff:2026-10-13:2026-10-12 -->

### 1.1.5. majkee tasks

- `raw/flight-review.md`
- `raw/majkee-gavels.2026-10-12.md`
- `/home/hruzam/reposoma/_cold-start/card/CS.jev-implementation-00-build.flight-carrier.2026-10-12.md`
- `/home/hruzam/reposoma/_cold-start/card/CS.jev-implementation-00-build.cartan-head.2026-10-12.md`

---

### 1.1.6. tunnel setting and run.

Bed: `/home/hruzam/ia-sync/.dev/session/jev-implementation-00-build/`
Vault: `tunnel.head.state.json` in that bed.
Head candidate thread: `01a0f5b9-b2ae-7392-af89-f434d5536d88` (gpt-6.1-sol / high / on-request / user, 17.2% at last check).

Before enabling: release the interactive Codex client on this thread. Never bind while a TUI session holds the writer lock.

**1 — open and enable** (operator runs once, after releasing the interactive client):

```zsh
TUNNEL_CODEX_STATE=/home/hruzam/ia-sync/.dev/session/jev-implementation-00-build/tunnel.head.state.json \
  zsh /home/hruzam/.config/zsh/ai/tunnel-codex.zsh open --enable \
  --thread 01a0f5b9-b2ae-7392-af89-f434d5536d88 --cwd /home/hruzam/ia-sync
```

This binds the existing thread. Model, sandbox and approval policy are inherited from the thread; they are not reset by the command defaults. Keep the intended `workspace-write` / `on-request` policy — do not silently choose `never` or `full-access` to avoid an approval conversation.

**2 — first resume** (Flight, after the operator's `open --enable` completes):

```zsh
TUNNEL_CODEX_STATE=/home/hruzam/ia-sync/.dev/session/jev-implementation-00-build/tunnel.head.state.json \
  zsh /home/hruzam/.config/zsh/ai/tunnel-codex.zsh resume
```

After resuming, Flight inspects `state.runtime` (`jq '.threadId, .runtime' "$TUNNEL_CODEX_STATE"`) and records the effective cwd, model, approval policy and sandbox. A `READY` result from `tn-check` alone is not sufficient; require the operator's explicit release of the interactive client before any bind or resume.

**3 — read-only preflight** (safe any time, no turn spent):

```zsh
source /home/hruzam/ia-sync/zsh/session/tunnel.zsh
_tn_check --id 01a0f5b9-b2ae-7392-af89-f434d5536d88 --cwd /home/hruzam/ia-sync
```

Serialization rules apply: one vault, one carrier, one turn at a time. See `tunnel-using-protocole.md` §Serialization and recovery for exit-code handling (50, 61, 13) and unknown-completion recovery.

---

# 2. NABLARVA

Reserved for the Nablarva owner’s supplied state. Do not infer or duplicate its live STATUS here.

---
session : `guide-model-01-law` (Codex · myShell · backlog steward)
---

# 3. GUIDE-MODEL — cross-runbook backlog background (bed: `/home/hruzam/ia-sync/.dev/session/guide-model-01-law`, head: myShell)

- [x] Created the bounded ia-sync session with a fixed RUNBOOK, one STATUS owner, and a small program that indexes work turns without replacing an owning bed's STATUS. · evidence: `/home/hruzam/ia-sync/.dev/session/guide-model-01-law/`
- [X] Majkee provides the first recent work-turn account for concise cross-scope indexing. · `STATUS.md` has it

**Continue here:** describe the latest work turn—scope, durable evidence or path, uncertainty, and desired follow-up—then myShell will reconcile it into the program.

**Scope correction:** this is the third log-session task. myShell is its bounded status steward; the required execution head is the existing Astrobley session, which must be resumed or bound rather than replaced.

- [x] Preserved and verified the Claude/Opus Symmetry design drop: the ZIP passed integrity testing, its 12 files were extracted unchanged under this bed's `raw/`, and no supplied script was run. · evidence: `raw/SYMMETRY-CATALOG.2026-10-13.md`
- [x] Preserved the cSharp Astrobley assignment as a non-executing session POINT: GUIDE is Astrobley's space; BACKGROUND and PADs remain Majkee's; any single Opus Atlas-ui consultation must travel through Majkee. · evidence: `raw/POINT.myShell-to-Astrobley.2026-10-13.md`
- [x] Prepared a private performative-Codex controller space with launch instructions, bounded-spawn rules, a one-relay Atlas-ui seam, and an immutable return ledger; myShell alone carries its receipts upward. · evidence: `performative-codex/LAUNCH.md`
- [x] Prepared an unsent Claude/Atlas-ui orientation POINT that names the colleagues, Majkee's carrier/gavel role, and the prospective Cartan cSharp seam without pretending it is already live. · evidence: `_bus/00.myShell-to-Atlas-ui.sync.POINT.md`
- [X] Majkee may carry the Atlas-ui POINT verbatim; no receipt is expected. `STATUS.md` holds the exact next action.

**Head correction:** Astrobley was invoked only long enough to surface a gate/ownership curvature, then stopped when Majkee chose a fresh performative Codex controller. Astrobley's POINT remains substrate; `performative-codex/LAUNCH.md` is the live launch surface.

**Parked Atlas companion:** `claude --resume "ff-sync.atlas.guide-model-01-law.harness"` — use later for the Atlas fidelity review of `raw/RECONCILIATION.germline-02-guide-model-law.2026-10-13.md`; this is companion context, not a live execution instruction.

**Later myShell/Majkee task:** design a small programmatic semantic for collaborative journaling actions: capture what we did, the durable evidence, actor/authority, and the next appropriate follow-up without competing with any session `STATUS.md`. Observe useful fields during today’s work; do not design or install it inside this guide-model gate.

**Observed transition (2026-10-14):** the historical references above to this bed’s `STATUS.md`,
`PROGRAM.md`, and canonical `RUNBOOK.md` no longer resolve; the old v3/strict-GUIDE launcher is
therefore not live. The current prepared inputs are `raw/RECONCILIATION.germline-02-guide-model-law.2026-10-13.md`,
`raw/SOURCE-ACCOUNTING.germline-02-guide-model-law.2026-10-14.md`, and the Atlas fidelity POINT.
They await an Atlas return and Majkee gavel; no v3 installation or conversion follows from this
historical chapter.

## Launch prompts — erase after use

### Atlas-UI

> myShell, please write fresh SNAPSHOT to-atlas (each time) here:
> *(SNAPSHOT ID: `2`)*
```text
from-cartan to-atlas ---


```

### Cartan *(`cSharp`)* / Medusa proposal release

> myShell, please write fresh SNAPSHOT to-cartan (each time) here:
> *(SNAPSHOT ID: `3`)*
```text

```

# 4. MYSHELL — collaborative relay and delegation vault

This is a coordination index for Majkee and myShell. It does not replace an owning session’s
`STATUS.md`, RUNBOOK, or cold-start card.

**Q1: controller?**
```++CONTROLLER++```

## Gavel sitting — decision carriage to Cartan

**Method observation:** the external myShell gavel loop proved useful: one candidate row at a
time, alternatives and commitments visible before Majkee supplied words, and authority remained
with Majkee. Codex's skill-driven driver can flex beside the existing Claude full-agent harness.
This is an observation only—not a new agent, skill, loader, canon rule, or session mechanism.

---

## Human relay tags

Use a tag only when the message must cross a human-held or independent-session seam. Put the
tag on its own line, then provide the smallest self-contained packet: purpose, exact evidence
path(s), requested response, authority, and stop condition.

```text
to-majkee ---
decision or gavel needed: <one sentence>
evidence: <absolute or durable path>
options / recommendation: <short>
stop: <what remains frozen until reply>
```

```==TEMPLATES==```

```text
to-myShell ---
integration or journal action requested: <one sentence>
evidence: <path(s)>
expected record: <journal / reconciliation / relay receipt>
authority: <what myShell may and may not change>
```

```text
to-atlas ---
consult question: <one bounded question>
read first: <path(s)>
return: <PASS or findings, destination>
authority: consult only; no implementation
```

```text
to-cartan ---
head task: <one bounded gate>
read first: <card / RUNBOOK / STATUS paths>
authority: <planning or execution boundary>
done when: <evidence>
```

Subagents do not use these tags. Their prompt and return stay in their native vendor style;
myShell alone translates a result into a human relay when a participant needs it.

## Local call IDs — not new agent roles

| call ID | use only when | receive | return / limit |
|---|---|---|---|
| `myShell.luna.scan` | narrow inventory, path classification, or link/pointer scan | exact roots, question, read-only rule, expected table | findings with paths; no interpretation of canon, no writes |
| `myShell.astra.reconcile` | conflicting sources need a careful retained/changed/superseded account | bounded source list, current verdict, sealed-file exclusions | evidence matrix and unresolved gavel items; no integration write |
| `myShell.astrobley.build` | a RUNBOOK assigns exact implementation/test paths after a gavel | RUNBOOK step, allowed paths, acceptance evidence, explicit exclusions | changed paths and verification; no canon, commit, deploy, or scope expansion |
| `myShell.verifier.witness` | an independent fresh-reader check is required after a build | exact artifact, declared read path, witness cases, no-write boundary | PASS/FAIL and unproven claims; never fixes the artifact |

### Exact native-call examples

`myShell.luna.scan` is the default cheap tentacle. Use one fresh, read-only child:

```text
spawn_agent(
  task_name="myshell_luna_scan_<scope>", fork_turns="none",
  model="gpt-6-luna", reasoning_effort="medium",
  message="Read-only scan. Scope: <exact paths>. Question: <one question>.\n"
          "Do not write, execute staged scripts, or read <sealed paths>.\n"
          "Return: <named table/findings and path citations>."
)
```

`myShell.astra.reconcile` resumes the existing reconciliation advisor rather than spawning a
second integrator. Pass the changed source list, the current working verdict, and the exact
accounting question. Its output is evidence for myShell, not a gavel.

`myShell.astrobley.build` is never a substitute for Luna or the advisor. Call the installed
role only after a RUNBOOK creates a bounded build surface:

```text
spawn_agent(
  task_name="myshell_astrobley_<runbook-step>", agent_type="astrobley",
  message="Execute RUNBOOK <path>, step <id>. Allowed paths: <list>.\n"
          "Acceptance evidence: <tests/witness>. Exclusions: <list>.\n"
          "Return changed paths, commands, results, and remaining gate."
)
```

The controller remains the session head and STATUS owner. A call ID describes the purpose of
one delegation; it never changes the child’s vendor role, model contract, or project authority.

## HELPERS

> myShell, block for helper log here:
```text
2026-10-15 · myShell — helper shelf

Created the small, operator-requested command shelf at `.majkee/helpers/`:
`git/HELP.md` holds `git add -A` with two session-bed exclusions plus staged-review
commands; `tree/HELP.md` and `grep/HELP.md` hold one compact inspection example each.
The first combined note was split by theme. Verified the Markdown diff and that `tree`
and `grep` are installed. No commit or push.
```

### Carry receipts — 2026-10-16

- CARRIED TO `journal/2026-10-16.md` §1.1–§1.3 · `2026-10-16 germline-03 relay packets`.
  The prepared project frame and the bounded Cartan/Atlas relay packets remain pointers, not
  project truth or an opening authorization.
- CARRIED TO `journal/2026-10-16.md` §2–§4 · `2026-10-16 cross-day owner-state check`.
  JEV remains under its own STATUS; Nablarva awaits its owner's supplied state; guide-model has
  no current STATUS/RUNBOOK and is carried only as an unresolved owner-state gap. Original
  source text remains unchanged.
